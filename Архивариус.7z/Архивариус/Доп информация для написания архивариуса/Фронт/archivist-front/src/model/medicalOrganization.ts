export interface MedicalOrganization<> {
  moList: [
    {
      shortName: string;
      codeMo: string;
      isShown: boolean;
    }
  ];
}
