export interface Patient {
  lastName: string;
  firstName: string;
  middleName: string;
  snils: string;
  enp: string;
  birthDate: Date;
}
