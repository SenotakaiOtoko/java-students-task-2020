export interface Data {
  userId: number;
  cardNumber: string;
  lastName: string;
  firstName: string;
  middleName: string;
  snils: string;
  enp: string;
  birthDate: Date;
  remdResult: string;
  codeMo: string;
}
