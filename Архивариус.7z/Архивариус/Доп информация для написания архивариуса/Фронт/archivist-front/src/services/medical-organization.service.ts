import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Environment } from '../model/environment';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';
import { MedicalOrganization } from '../model/medicalOrganization';

@Injectable({
  providedIn: 'root',
})
export class MedicalOrganizationService {
  _env: Environment = environment;
  constructor(private http: HttpClient) {}

  getMedOrg(): Observable<MedicalOrganization> {
    return this.http.get<MedicalOrganization>(`${this._env.url}/mo`);
  }
}
