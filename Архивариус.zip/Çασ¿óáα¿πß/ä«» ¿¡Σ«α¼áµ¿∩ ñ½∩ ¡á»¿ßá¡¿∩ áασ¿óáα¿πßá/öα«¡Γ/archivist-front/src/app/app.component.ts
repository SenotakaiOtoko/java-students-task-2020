import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith, switchMap, tap } from 'rxjs/operators';
import { PatientService } from '../services/patient.service';
import { MedicalOrganizationService } from '../services/medical-organization.service';
import { MedicalOrganization } from '../model/medicalOrganization';
import { MedicalOrganizationList } from '../model/medicalOrganizationList';
import { IemkPatientList } from '../model/iemkPatientList';
import { Patient } from '../model/patient';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'archivarius';
  form: FormGroup;
  showMedOrg: MedicalOrganization;
  patientLastName: string;
  patientSnils: string;
  patientInfo: IemkPatientList;

  constructor(
    private patient: PatientService,
    private medOrg: MedicalOrganizationService
  ) {}

  selectedMedOrg: string;
  searchForm: FormGroup;

  ngOnInit(): void {
    this.form = new FormGroup({
      medicalOrg: new FormControl(),
      patientSnils: new FormControl(),
      patientLastName: new FormControl(),
      patientName: new FormControl(),
      patientPatrName: new FormControl(),
      patientBirthDay: new FormControl(),
      patientOms: new FormControl(),
      patientCardNumber: new FormControl(),
    });
    this.searchForm = new FormGroup({
      medicalOrg: new FormControl(),
      patientSnils: new FormControl(),
      patientLastName: new FormControl(),
    });
    this.medOrg.getMedOrg().subscribe((data) => {
      this.showMedOrg = data;
    });
  }

  submit(value) {
    console.log(this.form);
    console.log(
      value.patientCardNumber,
      value.patientLastName,
      value.patientName,
      value.patientPatrName,
      value.patientSnils,
      value.patientOms,
      value.patientBirthDay,
      value.medicalOrg.codeMo
    );
    this.patient
      .putPatient(
        3337,
        value.patientCardNumber,
        value.patientLastName,
        value.patientName,
        value.patientPatrName,
        value.patientSnils,
        value.patientOms,
        value.patientBirthDay,
        value.medicalOrg.codeMo,
        'success'
      )
      .subscribe((data) => {
        console.log(data);
      });
  }

  submitSearch(value: any) {
    console.log(value);
    this.patient
      .getPatient(value.patientSnils, value.patientLastName)
      .subscribe((patient) => {
        this.patientInfo = patient;
        console.log(patient.patientList[0]);
        this.form.patchValue({
          medicalOrg: this.searchForm.get('medicalOrg').value,
          patientSnils: this.searchForm.get('patientSnils').value,
          patientLastName: this.searchForm.get('patientLastName').value,
          patientName: patient.patientList[0].firstName,
          patientPatrName: patient.patientList[0].middleName,
          patientBirthDay: patient.patientList[0].birthDate,
          patientOms: patient.patientList[0].enp,
        });
      });
  }
}
