export interface Environment {
  url: string;
  production: boolean;
}
