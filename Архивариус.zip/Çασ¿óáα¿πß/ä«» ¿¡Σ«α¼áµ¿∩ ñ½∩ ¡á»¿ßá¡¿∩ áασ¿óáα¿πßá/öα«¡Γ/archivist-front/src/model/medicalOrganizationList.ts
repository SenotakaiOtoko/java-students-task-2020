export interface MedicalOrganizationList {}
