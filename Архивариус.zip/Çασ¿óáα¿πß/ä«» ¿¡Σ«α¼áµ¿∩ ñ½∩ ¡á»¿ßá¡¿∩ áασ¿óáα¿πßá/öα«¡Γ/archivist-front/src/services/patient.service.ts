import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Environment } from '../model/environment';
import { IemkPatientList } from '../model/iemkPatientList';
import { environment } from '../environments/environment';
import { Data } from '../model/data';

@Injectable({
  providedIn: 'root',
})
export class PatientService {
  _env: Environment = environment;
  constructor(private http: HttpClient) {}

  getPatient(
    patientSnils?: string,
    patientLastName?: string
  ): Observable<IemkPatientList> {
    return this.http.get<IemkPatientList>(`${this._env.url}/iemk`, {
      params: {
        patientSnils: patientSnils,
        patientLastName: patientLastName,
      },
    });
  }

  putPatient(
    userId?: number,
    cardNumber?: string,
    lastName?: string,
    firstName?: string,
    middleName?: string,
    snils?: string,
    enp?: string,
    birthDate?: Date,
    codeMo?: string,
    remdResult?: string
  ): Observable<Data> {
    return this.http.post<Data>(`${this._env.url}/data`, {
      userId: userId,
      cardNumber: cardNumber,
      lastName: lastName,
      firstName: firstName,
      middleName: middleName,
      snils: snils,
      enp: enp,
      birthDate: birthDate,
      remdResult: remdResult,
      codeMo: codeMo,
    });
  }
}
